# AI-Powered Workforce Analytics - Backend + RAG

This package contains ONLY:

```text
backend/
rag/
```

It is designed to use your existing:

```text
data/
ML/
```

folders.

## Your existing structure

```text
AI-Powered-Workforce-Analytics/
├── backend/
├── rag/
├── ML/
│   ├── Feature_Classification.xlsx
│   ├── ML part.docx
│   ├── ML_Ready_Dataset.csv
│   ├── X_test.csv
│   ├── X_train.csv
│   ├── y_test.csv
│   └── y_train.csv
├── data/
│   ├── workforce processed data.csv
│   └── workforce data.csv
└── frontend/
```

The screenshot-provided filenames are handled by the RAG discovery code.

## 1. Install

From the project root:

```bash
cd backend
python -m venv venv
```

Windows:

```bash
venv\Scripts\activate
```

Install:

```bash
pip install -r requirements.txt
```

## 2. Start backend

```bash
python app.py
```

API:

```text
http://127.0.0.1:5000
```

Health:

```text
GET /api/health
```

## 3. Build RAG index

Open another terminal in the project root:

```bash
python -m rag.build_index
```

Or:

```text
POST /api/rag/rebuild
```

## 4. RAG question

```text
POST /api/rag/ask
```

Body:

```json
{
  "question": "Explain the ML dataset and its features."
}
```

## 5. Existing ML connection

The backend does not duplicate your ML files.

`backend/services/prediction_service.py` adds the existing `ML/` directory
to Python's import path and looks for:

```python
predict_attrition(payload)
```

or:

```python
predict(payload)
```

or:

```python
make_prediction(payload)
```

inside:

```text
ML/prediction.py
```

If your existing prediction filename/function is different, only that adapter
needs to be changed.

## 6. Main backend APIs

```text
GET  /api/health
GET  /api/dashboard/
GET  /api/employees/
GET  /api/analytics/overview
GET  /api/analytics/performance
GET  /api/analytics/salary
GET  /api/analytics/attrition
GET  /api/analytics/departments
POST /api/predict/attrition
POST /api/chat/
POST /api/rag/ask
POST /api/rag/rebuild
```
