from pathlib import Path
import sys

# Connect to the user's existing ML folder.
PROJECT_ROOT = Path(__file__).resolve().parents[2]
ML_DIR = PROJECT_ROOT / "ML"

if str(ML_DIR) not in sys.path:
    sys.path.insert(0, str(ML_DIR))


def predict_attrition(payload):
    """
    Adapter for an existing ML prediction module.

    The backend first looks for common function names in ML/prediction.py.
    If your ML file uses another filename/function, change only this adapter.
    """
    try:
        import prediction
    except ImportError as exc:
        raise RuntimeError(
            "Could not import ML/prediction.py. "
            "Place your prediction code in the existing ML folder or update "
            "backend/services/prediction_service.py."
        ) from exc

    for function_name in (
        "predict_attrition",
        "predict",
        "make_prediction"
    ):
        function = getattr(prediction, function_name, None)
        if callable(function):
            return function(payload)

    raise RuntimeError(
        "No supported prediction function found. "
        "Expected predict_attrition(payload), predict(payload), "
        "or make_prediction(payload)."
    )
