import pandas as pd


def find_col(df, *names):
    for name in names:
        if name in df.columns:
            return name
    return None


def summary(df):
    if df is None or df.empty:
        return {}

    attr = find_col(df, "Attrition")
    income = find_col(df, "MonthlyIncome", "Salary")
    performance = find_col(df, "PerformanceRating", "Performance")
    satisfaction = find_col(df, "JobSatisfaction", "Satisfaction")
    tenure = find_col(df, "YearsAtCompany", "Tenure")

    attr_rate = 0
    if attr:
        attr_rate = float(
            df[attr].astype(str).str.lower().eq("yes").mean() * 100
        )

    return {
        "total_employees": int(len(df)),
        "attrition_rate": round(attr_rate, 2),
        "average_salary": round(
            pd.to_numeric(df[income], errors="coerce").mean(), 2
        ) if income else 0,
        "average_performance": round(
            pd.to_numeric(df[performance], errors="coerce").mean(), 2
        ) if performance else 0,
        "average_satisfaction": round(
            pd.to_numeric(df[satisfaction], errors="coerce").mean(), 2
        ) if satisfaction else 0,
        "average_tenure": round(
            pd.to_numeric(df[tenure], errors="coerce").mean(), 2
        ) if tenure else 0,
    }


def department_stats(df):
    col = find_col(df, "Department")
    attr = find_col(df, "Attrition")
    if not col:
        return []

    output = []
    for department, group in df.groupby(col, dropna=False):
        item = {
            "department": str(department),
            "employees": int(len(group))
        }
        if attr:
            item["attrition_rate"] = round(
                group[attr].astype(str).str.lower().eq("yes").mean() * 100, 2
            )
        output.append(item)
    return output


def performance_stats(df):
    col = find_col(df, "PerformanceRating", "Performance")
    if not col:
        return []

    series = pd.to_numeric(df[col], errors="coerce").dropna()
    return [
        {"rating": float(v), "employees": int((series == v).sum())}
        for v in sorted(series.unique())
    ]


def salary_stats(df):
    col = find_col(df, "MonthlyIncome", "Salary")
    if not col:
        return {}

    series = pd.to_numeric(df[col], errors="coerce").dropna()
    return {
        "average": round(series.mean(), 2),
        "minimum": round(series.min(), 2),
        "maximum": round(series.max(), 2),
        "median": round(series.median(), 2)
    }


def attrition_stats(df):
    attr = find_col(df, "Attrition")
    if not attr:
        return {}

    yes = int(df[attr].astype(str).str.lower().eq("yes").sum())
    no = int(df[attr].astype(str).str.lower().eq("no").sum())

    result = {
        "yes": yes,
        "no": no,
        "rate": round(yes / len(df) * 100, 2) if len(df) else 0
    }

    if "Department" in df.columns:
        result["by_department"] = department_stats(df)

    if "JobRole" in df.columns:
        result["by_job_role"] = []
        for role, group in df.groupby("JobRole", dropna=False):
            result["by_job_role"].append({
                "job_role": str(role),
                "employees": int(len(group)),
                "attrition_rate": round(
                    group[attr].astype(str).str.lower().eq("yes").mean() * 100, 2
                )
            })

    return result
