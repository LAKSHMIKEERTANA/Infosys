from pathlib import Path
import pandas as pd


def load_dataset(path):
    path = Path(path)

    if not path.exists():
        # Try the processed CSV visible in the user's project.
        alternatives = [
            path.parent / "workforce processed data.csv",
            path.parent / "workforce_processed.csv",
            path.parent / "workforce data.csv",
        ]
        for candidate in alternatives:
            if candidate.exists():
                path = candidate
                break

    if not path.exists():
        raise FileNotFoundError(
            f"Dataset not found. Expected: {path}"
        )

    suffix = path.suffix.lower()
    if suffix == ".csv":
        df = pd.read_csv(path)
    elif suffix in {".xlsx", ".xls"}:
        df = pd.read_excel(path)
    else:
        raise ValueError("Only CSV, XLSX and XLS datasets are supported.")

    df.columns = (
        df.columns.astype(str)
        .str.strip()
        .str.replace(" ", "_", regex=False)
        .str.replace("-", "_", regex=False)
    )

    return df.drop_duplicates().reset_index(drop=True)


def records(df):
    return df.where(pd.notnull(df), None).to_dict(orient="records")
