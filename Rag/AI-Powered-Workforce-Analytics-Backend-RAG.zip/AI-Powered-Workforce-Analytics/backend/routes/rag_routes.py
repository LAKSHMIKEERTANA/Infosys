from flask import Blueprint, jsonify, request
from rag.rag_service import ask_rag, build_index

rag_bp = Blueprint("rag", __name__)


@rag_bp.post("/ask")
def ask():
    payload = request.get_json(silent=True) or {}
    question = payload.get("question", "").strip()

    if not question:
        return jsonify({"error": "question is required"}), 400

    try:
        result = ask_rag(question)
        return jsonify(result)
    except Exception as exc:
        return jsonify({"error": str(exc)}), 500


@rag_bp.post("/rebuild")
def rebuild():
    try:
        result = build_index()
        return jsonify(result)
    except Exception as exc:
        return jsonify({"error": str(exc)}), 500
