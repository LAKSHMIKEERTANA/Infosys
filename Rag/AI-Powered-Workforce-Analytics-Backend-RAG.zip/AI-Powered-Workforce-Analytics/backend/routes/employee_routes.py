from flask import Blueprint, current_app, jsonify, request
from utils.data_loader import records

employee_bp = Blueprint("employees", __name__)


@employee_bp.get("/")
def employees():
    df = current_app.config["DATA"]
    if df is None:
        return jsonify({"error": current_app.config["DATA_ERROR"]}), 500

    result = df.copy()
    search = request.args.get("search", "").lower().strip()
    department = request.args.get("department", "").lower().strip()
    job_role = request.args.get("job_role", "").lower().strip()

    if search:
        mask = result.astype(str).apply(
            lambda c: c.str.lower().str.contains(search, na=False)
        ).any(axis=1)
        result = result[mask]

    if department and "Department" in result.columns:
        result = result[
            result["Department"].astype(str).str.lower().eq(department)
        ]

    if job_role and "JobRole" in result.columns:
        result = result[
            result["JobRole"].astype(str).str.lower().eq(job_role)
        ]

    try:
        limit = min(max(int(request.args.get("limit", 100)), 1), 1000)
    except ValueError:
        limit = 100

    return jsonify({
        "count": int(len(result)),
        "employees": records(result.head(limit))
    })
