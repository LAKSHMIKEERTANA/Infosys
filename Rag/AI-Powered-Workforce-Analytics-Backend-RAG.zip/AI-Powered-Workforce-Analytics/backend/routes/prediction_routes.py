from flask import Blueprint, jsonify, request
from services.prediction_service import predict_attrition

prediction_bp = Blueprint("prediction", __name__)


@prediction_bp.post("/attrition")
def attrition():
    payload = request.get_json(silent=True)

    if not isinstance(payload, dict):
        return jsonify({"error": "JSON object required."}), 400

    try:
        return jsonify(predict_attrition(payload))
    except Exception as exc:
        return jsonify({"error": str(exc)}), 400
