from flask import Blueprint, current_app, jsonify, request
from services.analytics_service import summary, attrition_stats, department_stats

chat_bp = Blueprint("chat", __name__)


@chat_bp.post("/")
def chat():
    df = current_app.config["DATA"]
    if df is None:
        return jsonify({"error": current_app.config["DATA_ERROR"]}), 500

    question = (request.get_json(silent=True) or {}).get("question", "")
    q = question.lower()

    if "attrition" in q or "turnover" in q:
        data = attrition_stats(df)
        return jsonify({
            "answer": f"The dataset attrition rate is {data.get('rate', 0)}%.",
            "data": data
        })

    if "department" in q:
        return jsonify({
            "answer": "Here is the department-level analysis.",
            "data": department_stats(df)
        })

    data = summary(df)
    return jsonify({
        "answer": f"The dataset contains {data.get('total_employees', 0)} employees.",
        "data": data
    })
