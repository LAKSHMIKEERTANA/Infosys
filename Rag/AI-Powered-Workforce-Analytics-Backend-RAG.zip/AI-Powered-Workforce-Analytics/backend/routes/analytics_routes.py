from flask import Blueprint, current_app, jsonify
from services.analytics_service import (
    summary, performance_stats, salary_stats,
    attrition_stats, department_stats
)

analytics_bp = Blueprint("analytics", __name__)


def data_or_error():
    df = current_app.config["DATA"]
    if df is None:
        return None, jsonify({"error": current_app.config["DATA_ERROR"]}), 500
    return df, None, None


@analytics_bp.get("/overview")
def overview():
    df, error, status = data_or_error()
    if error:
        return error, status
    return jsonify(summary(df))


@analytics_bp.get("/performance")
def performance():
    df, error, status = data_or_error()
    if error:
        return error, status
    return jsonify(performance_stats(df))


@analytics_bp.get("/salary")
def salary():
    df, error, status = data_or_error()
    if error:
        return error, status
    return jsonify(salary_stats(df))


@analytics_bp.get("/attrition")
def attrition():
    df, error, status = data_or_error()
    if error:
        return error, status
    return jsonify(attrition_stats(df))


@analytics_bp.get("/departments")
def departments():
    df, error, status = data_or_error()
    if error:
        return error, status
    return jsonify(department_stats(df))
