from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = BASE_DIR.parent

DATA_DIR = PROJECT_ROOT / "data"
ML_DIR = PROJECT_ROOT / "ML"
MODEL_DIR = ML_DIR / "saved_models"

# Your screenshot shows this filename in the data folder.
DATA_FILE = DATA_DIR / "workforce data.csv"

# RAG uses the existing ML and data folders.
RAG_DIR = PROJECT_ROOT / "rag"
RAG_STORE_DIR = RAG_DIR / "vector_store"

MODEL_DIR.mkdir(parents=True, exist_ok=True)
RAG_STORE_DIR.mkdir(parents=True, exist_ok=True)
